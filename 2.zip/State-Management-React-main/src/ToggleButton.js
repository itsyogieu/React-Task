import React, { useState } from 'react';

const ToggleButton = () => {
  const [isOn, setIsOn] = useState(false);
  const toggle = () => {
    setIsOn(!isOn);
  };

  return (
    <div>
      <h1>Toggle: {isOn ? "ON" : "OFF"}</h1>
      <button onClick={toggle}>{isOn ? "Turn OFF" : "Turn ON"}</button>
    </div>
  );
};

export default ToggleButton;
