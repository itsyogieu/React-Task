import React from 'react';
const MyButton = () => {
  return (
    <button>
      Click Me!
    </button>
  );
};
export default MyButton;
