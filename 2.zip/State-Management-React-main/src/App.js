import React from 'react';
import Counter from './Counter';
import ToggleButton from './ToggleButton';

const App = () => {
  return (
    <div>
      <h1>React State Management</h1>
      <Counter />
      <ToggleButton />
    </div>
  );
};

export default App;

