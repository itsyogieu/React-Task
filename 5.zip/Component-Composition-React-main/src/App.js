
import React from 'react';
import DisplayWidth from './DisplayWidth';

function App() {
  return (
    <div className="App">
      <h1>Window Width Example</h1>
      <DisplayWidth />
    </div>
  );
}

export default App;

