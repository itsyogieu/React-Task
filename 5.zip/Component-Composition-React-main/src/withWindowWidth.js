import React, { Component } from 'react';

const withWindowWidth = WrappedComponent => {
  return class extends Component {
    state = {
      width: window.innerWidth
    };

    handleResize = () => {
      this.setState({ width: window.innerWidth });
    };

    componentDidMount() {
      window.addEventListener('resize', this.handleResize);
    }

    componentWillUnmount() {
      window.removeEventListener('resize', this.handleResize);
    }

    render() {
      return <WrappedComponent width={this.state.width} {...this.props} />;
    }
  };
};

export default withWindowWidth;
