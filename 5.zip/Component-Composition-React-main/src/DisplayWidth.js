

import React from 'react';
import useWindowWidth from './useWindowWidth';

const DisplayWidth = () => {
  const width = useWindowWidth();
  return <div>Window width is: {width}px</div>;
};

export default DisplayWidth;

