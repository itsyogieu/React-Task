import React, { Component } from 'react';

class WindowWidthProvider extends Component {
  state = {
    width: window.innerWidth
  };

  handleResize = () => {
    this.setState({ width: window.innerWidth });
  };

  componentDidMount() {
    window.addEventListener('resize', this.handleResize);
  }

  componentWillUnmount() {
    window.removeEventListener('resize', this.handleResize);
  }

  render() {
    return this.props.children(this.state.width);
  }
}

export default WindowWidthProvider;
