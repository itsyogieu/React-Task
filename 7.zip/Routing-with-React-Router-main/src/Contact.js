import React from 'react';

const Contact = () => {
  return (
    <div>
      <h2>Contact Page</h2>
      <p>Get in touch with us through this page.</p>
    </div>
  );
};

export default Contact;
