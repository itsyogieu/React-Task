import React from 'react';
import MyButton from './MyButton'; 
const App = () => {
  return (
    <div>
      <h1>Welcome to My React App</h1>
      <MyButton />
    </div>
  );
};
export default App;
