
import React from 'react';

const Footer = ({ count }) => {
  return <footer>Count: {count}</footer>;
};

export default Footer;
