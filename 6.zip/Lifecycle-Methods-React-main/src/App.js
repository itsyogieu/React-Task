// src/App.js
import React from 'react';
import './App.css';
import LifecycleComponent from './LifecycleComponent';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <LifecycleComponent />
      </header>
    </div>
  );
}

export default App;


