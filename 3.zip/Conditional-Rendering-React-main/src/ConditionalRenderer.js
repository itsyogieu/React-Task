import React, { useState } from 'react';

const ConditionalRenderer = ({ status }) => {
  const [loggedIn, setLoggedIn] = useState(false);
  const toggleLogin = () => {
    setLoggedIn(!loggedIn);
  };
  const renderStatusMessage = () => {
    if (status === 'success') {
      return <p>Operation was successful!</p>;
    } else if (status === 'error') {
      return <p>There was an error.</p>;
    } else {
      return <p>Status is unknown.</p>;
    }
  };

  return (
    <div>
      <h1>Conditional Rendering Example</h1>
      {loggedIn && <p>Welcome, User!</p>}
      <p>{loggedIn ? 'You are logged in.' : 'You are not logged in.'}</p>
      <button onClick={toggleLogin}>
        {loggedIn ? 'Log Out' : 'Log In'}
      </button>

      
      <div>{renderStatusMessage()}</div>
    </div>
  );
};

export default ConditionalRenderer;
