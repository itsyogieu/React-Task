import React from 'react';
import ConditionalRenderer from './ConditionalRenderer';

const App = () => {
  return (
    <div>
      <ConditionalRenderer status="success" />
      <ConditionalRenderer status="error" />
      <ConditionalRenderer status="unknown" />
    </div>
  );
};

export default App;
