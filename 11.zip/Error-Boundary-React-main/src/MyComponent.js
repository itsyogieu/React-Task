import React from 'react';

class MyComponent extends React.Component {
  render() {
    // Intentional error for testing
    throw new Error('Test error');
    return <div>My Component</div>;
  }
}

export default MyComponent;
