import React from 'react';
import ControlledForm from './ControlledForm';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1>Controlled Form Example</h1>
      <ControlledForm />
    </div>
  );
}

export default App;

