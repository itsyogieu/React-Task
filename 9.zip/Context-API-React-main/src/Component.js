
import React from 'react';
import { connect } from 'react-redux';

const Component = ({ stateProp, updateState }) => {
    
};

const mapStateToProps = (state) => ({
    stateProp: state.property
});

const mapDispatchToProps = (dispatch) => ({
    updateState: (newState) => dispatch({ type: 'UPDATE_STATE', payload: newState })
});

export default connect(mapStateToProps, mapDispatchToProps)(Component);
