
import React, { useState } from 'react';
import AppContext from './AppContext';

const AppProvider = ({ children }) => {
    const [state, setState] = useState(initialState);

    const updateState = (newState) => {
        setState(prevState => ({ ...prevState, ...newState }));
    };

    return (
        <AppContext.Provider value={{ state, updateState }}>
            {children}
        </AppContext.Provider>
    );
};

export default AppProvider;
