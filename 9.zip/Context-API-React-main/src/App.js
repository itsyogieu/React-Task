
import React from 'react';

function App() {
    return (
        <div>
            {/* Your app content goes here */}
        </div>
    );
}

export default App;
