
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';


import PrivateRoute from './PrivateRoute';
import Login from './Login';
import Dashboard from './Dashboard';

function App() {
  return (
    <Router>
      <Switch>
        <Route path="/login" component={Login} />
        <PrivateRoute path="/dashboard" component={Dashboard} />
      </Switch>
    </Router>
  );
}

export default App;
